
public interface Nsql {
	public void runUpdate(String sql);
	public void runUpdate(String sql,Object[] params);
}
