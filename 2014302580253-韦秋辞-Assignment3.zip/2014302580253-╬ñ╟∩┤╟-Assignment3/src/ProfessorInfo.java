import java.util.Map;

public class ProfessorInfo {
	private Map<String, String> contactInfo;
	private String background;
	private String researchInterests;

	
	public ProfessorInfo(Map<String, String> contactInfo,
			String background, String researchInterests) {
		super();
		this.contactInfo = contactInfo;
		//����
		this.background = background;
		//�о���Ȥ����
		this.researchInterests = researchInterests;
	}

	//Email�Ļ�ȡ
	public String getEmail() {
		return contactInfo.get("email");
	}
    //�绰�Ļ�ȡ
	public String getPhone() {
		return contactInfo.get("phone");
	}
    
	public Map<String, String> getContactInfo() {
		return contactInfo;
	}

	public void setContactInfo(Map<String, String> contactInfo) {
		this.contactInfo = contactInfo;
	}

	public String getBackground() {
		return background;
	}

	public void setBackground(String background) {
		this.background = background;
	}

	public String getResearchInterests() {
		return researchInterests;
	}

	public void setResearchInterests(String researchInterests) {
		this.researchInterests = researchInterests;
	}

}