import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;


import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


//���ö��߳���ȡ��ҳ����ʵ�ֽ���
public class Crawler {
	ArrayList<String> allurl = new ArrayList<String>();//���е���ҳurl����Ҫ����Ч��ȥ�ؿ��Կ���HashSet  
    ArrayList<String> notCrawlurl = new ArrayList<String>();//δ��������ҳurl    
    int threadCount = 3; //�߳�����  
    int count = 0; //��ʾ�ж��ٸ��̴߳���wait״̬  
    public static final Object signal = new Object();   //�̼߳�ͨ�ű���  
//��ʼ��ȡ
	public static void main(String[] args) {
		final Crawler wc = new Crawler();  
        wc.addUrl("http://www.wpi.edu/academics/cs/research-interests.html");  
        long start= System.currentTimeMillis();  
        System.out.println("��ʼ����.........................................");  
        wc.begin();  
   //���Ƿ�����δ��ȡ����ҳ�ҵ�ǰ��Ծ���߳���Ϊ1���Ϳ�ʼ��ȡ       
        while(true){  
            if(wc.notCrawlurl.isEmpty()&& Thread.activeCount() == 1||wc.count==wc.threadCount){  
                long end = System.currentTimeMillis();  
                System.out.println("�ܹ�����"+wc.allurl.size()+"����ҳ");  
                System.out.println("�ܹ���ʱ"+(end-start)/1000+"��");  
                System.exit(1);  
//              break;  
            }               
        }  
    }  
		
//begin����
    private void begin() {  
    for(int i=0;i<threadCount;i++){  
        new Thread(new Runnable(){  
            public void run() {       
                while (true) {   
                    String s = getAUrl();  
                    if(s!=null){  
                        crawler2014302580253(s);  
                    }else{  
                    	//�����ȴ�
                        synchronized(signal) {
                            try {  
                                count++;  
                                System.out.println("��ǰ��"+count+"���߳��ڵȴ�");  
                                signal.wait();  
                            } catch (InterruptedException e) {  
  
                                e.printStackTrace();  
                            }  
                        }   
                    }  
                }  
            }  
        },"thread-"+i).start();  
    }
}
//��ȡһ��url
    public synchronized  String getAUrl() {  
    if(notCrawlurl.isEmpty())  
    	        return null;    
    String tmpAUrl;  
//  synchronized(notCrawlurlSet){  
        tmpAUrl= notCrawlurl.get(0);  
        notCrawlurl.remove(0);  
//  }  
		notifyAll();
    return tmpAUrl;  
}  
//����ȡ����url����������
    public synchronized void  addUrl(String url){  
    notCrawlurl.add(url);  
    allurl.add(url);  
    
}  

//��ȡ��ҳsUrl  
    public  void crawler2014302580253(String sUrl){  
    URL url;  
     try{ 
    	    String htmlPath="linkcontext.html";
         	HttpRequest response = HttpRequest.get(sUrl);
	        if (response.ok()) {
		    System.out.println("OK");
		    response.receive(new File(htmlPath));
            url = new URL(sUrl);  
            URLConnection urlconnection = url.openConnection();  
            urlconnection.addRequestProperty("User-Agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)");  
            InputStream is = url.openStream();  
            BufferedReader bReader = new BufferedReader(new InputStreamReader(is));  
            StringBuffer sb = new StringBuffer();//sbΪ��������ҳ����  
            String rLine = null;  
            while((rLine=bReader.readLine())!=null){  
                sb.append(rLine);  
                sb.append("/r/n");  
            }                       
            System.out.println("��ȥ��ҳ"+sUrl+"�ɹ� �����߳�"+Thread.currentThread().getName()+"����"); 
            parseContext(sb.toString());
	        }
     }
        catch (IOException e) {   
             e.printStackTrace();  
    }  
}  
    
    //��ȡ���� 
	// ��context�л�ȡurl��ַ,ʹ���������ʽ����ƥ�� ��ȡ��Ҫ������
    public  void parseContext(String context) {   

		ArrayList<String> validLinkList = new ArrayList<String>();
		String regex ="(www\\.wpi\\.edu/academics/(facultydir)|(datascience)/)(.+)";   
        Pattern pt = Pattern.compile(regex);  
        Matcher mc = pt.matcher(context); 
        //ȥ��
        if (mc.find() && (!validLinkList.contains(context))) {
			validLinkList.add(context);
		} else {
			System.out.println("not a professor's page");
		}
        //ȥ�����Ĳ���url�ĵ�ַ
        while (mc.find()) {  
//          System.out.println(mt.group());  
            Matcher myurl = Pattern.compile("href=\".*?\"").matcher(  
                    mc.group());  
            while(myurl.find()){  
                String str = myurl.group().replaceAll("href=\"|\"", "");  
                System.out.println("��ַ��:"+ str);  
                if(str.contains("http:")){ //ȡ��һЩ����url�ĵ�ַ  
                    if(!allurl.contains(str)){  
                        addUrl(str);//����һ���µ�url  
                        if(count>0){ //����еȴ����̣߳�����  
                            synchronized(signal) {  //---------------------��2��  
                                count--;  
                                signal.notify();  
                            }  
                        }  
                          
                    }  
                }  
            }  
        }  
        Iterator<String> validLinkListIter = validLinkList.iterator();
		while(validLinkListIter.hasNext()){
			String link = validLinkListIter.next();
			Pattern p = Pattern
					.compile("(www\\.wpi\\.edu/academics/(facultydir)|(datascience)/)(.+)");
			Matcher m = p.matcher(link);
			if (m.find()) {
				addUrl(link);
				validLinkListIter.remove();
			}
		}


	}
    
    //������ȡ������ҳ
    public static Document readHtml(File file) throws IOException {
		Document doc = Jsoup.parse(file, "GBK");
		return doc;
	}

	public static Document readHtml(String fileName) throws IOException {
		Document doc = Jsoup.parse(new File(fileName), "GBK");
		return doc;
	}
	//��ȡ��ʦ������
	public static String getName(Document doc) {
		String name = "";
		Elements headers = doc.getElementsByTag("h2");
		for (Element header : headers) {
			if (!header.ownText().equals("")) {
				name = header.ownText();
			}
		}
		return name;
	}
    
	//����������
	public static ArrayList<String> href() throws IOException,InterruptedException {
		
        Document doc = readHtml("linkcontext.html");
        Elements links = doc.getElementsByTag("a");
        ArrayList<String> linkList = new ArrayList<String>();
        for (Element link : links) {
	    linkList.add(link.attr("href"));
     }        
          return linkList;
    }

//��ȡһ����ʦ���������õ���Ϣ������Email���绰��
	private static HashMap<String, String> getContactInfo(Document doc) {
		Element contactInfo = doc.getElementById("contactinfo");
		String Str = contactInfo.toString();
		//Email������
		Pattern Email = Pattern.compile("[\\w]+@[\\w]+\\.[a-zA-Z]+");
		Matcher theEmail = Email.matcher(Str);
		HashMap<String, String> contactInfoMap = new HashMap<String, String>();
		if (theEmail.find()) {
			contactInfoMap.put("email", theEmail.group(0));
		}		
		//�绰���������
		Pattern Phone = Pattern.compile("\\+((\\-)?[\\d]+)+");
		Matcher thePhone = Phone.matcher(Str);		
		if (thePhone.find()) {
			contactInfoMap.put("phone", thePhone.group(0));
		}
		return contactInfoMap;
	}

	//��ȡ��ʦ�ı���
	private static String getBackground(Document doc) {
		//����������ȷ����Χ
		Elements e = doc.getElementsMatchingOwnText("Education");
		Element ee = e.get(0);
		Element Background = ee.nextElementSibling();
		Elements allBackgroundInfo = Background.getAllElements();
		String InfoStr = "";
		for (Element educationInfo : allBackgroundInfo) {
			if (educationInfo.hasText()) {
				InfoStr += educationInfo.ownText() + " ";
			}
		}
		return InfoStr;
	}

	//��ȡ��ʦ���о���Ȥ����	
	private static String getResearchInterests(Document doc) {
		Elements re = doc.getElementsMatchingOwnText("Research Interests");
		String rStr = "";
		if (re.hasText()) {
			Element rI = re.get(0);
			Element researchIn = rI.nextElementSibling();
			Elements allrI = researchIn.getAllElements();
			for (Element researchIns : allrI) {
				if (researchIns.hasText()) {
					rStr += researchIns.ownText() + "\n";
				}
			}
		} else {
		}
		return rStr;
	}

//��������Ϣѹ�����ݿ�
	public static ProfessorInfo getAllParams(File context) throws IOException {
		Document doc = readHtml(context);
		Map<String, String> contactInfo = getContactInfo(doc);
		String background = getBackground(doc);
		String researchInterests = getResearchInterests(doc);
		String name = getName(doc);
		String email = contactInfo.get("email");
		String phone = contactInfo.get("phone");
		Object[] params = { name, background, researchInterests,email, phone };
		ProfessorInfo p = new ProfessorInfo(contactInfo, background,researchInterests);
		System.out.println("new context processed");
		Sql s = new Sql();
		s.runUpdate(
				"insert into professor_info(name,background,researchInterests,email,phone) values(?,?,?,?,?)",
				params);
		return p;
	}
}
