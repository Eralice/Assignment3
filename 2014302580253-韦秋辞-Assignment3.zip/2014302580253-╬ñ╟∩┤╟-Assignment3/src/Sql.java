import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class Sql implements Nsql{
	
	private String url = "jdbc:mysql://127.0.0.1:3306/my_schema?"+
	"user=root&password=123456";
	
	private Connection getConnection(String url) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("�ɹ���������");
			Connection c = DriverManager.getConnection(url);
			return c;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}


	// û�в�����ʵ�ֲ���
	public void runUpdate(String sql) {
		Connection c = null;
		PreparedStatement p = null;
		try {
			c = getConnection(url);
			p = c.prepareStatement(sql);
			p.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				p.close();
				c.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	// �в�����ʵ�ַ���
	public void runUpdate(String sql, Object[] params) {
		Connection c = null;
		PreparedStatement p = null;
		try {
			c = getConnection(url);
			p = c.prepareStatement(sql);
			for (int i = 0; i < params.length; i++) {
				p.setObject(i + 1, params[i]);
			}
			p.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				p.close();
				c.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

public ResultSet runSelect(String sql){
	Connection c = null;
	PreparedStatement p = null;
	ResultSet res = null;
	try {
		c = getConnection(url);
		p = c.prepareStatement(sql);
		res = p.executeQuery();
		
	} catch (Exception e) {
		e.printStackTrace();
	} finally {
		try {
			p.close();
			c.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	return res;
}
}
